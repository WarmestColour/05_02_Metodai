import java.util.Scanner;

public class Uzd06 {

	public static void main(String[] args) {

		Scanner rd = new Scanner(System.in);
		System.out.println("Įveskite pirmą skaičių: ");
		int a = rd.nextInt();
		System.out.println("Įveskite paskutinį skaičių: ");
		int b = rd.nextInt();
		rd.close();
		int k = 2;

		int count = 0;

		for (int i = a; i <= b; i++) {

			if(i % k == 0) {
				count++;
			}
		}
		
		System.out.println(count);
		
		System.out.println(dalinasiIsK(a, b, k));
		System.out.println(count);
	}

	private static int dalinasiIsK(int a, int b, int k) {
		int count = 0;
		while (a <= b) {

			if (a % k == 0) {
				count++;
			}
			System.out.println(count);
		}
		return count;
	}
}