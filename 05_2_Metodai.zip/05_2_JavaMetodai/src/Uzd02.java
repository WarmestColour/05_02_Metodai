import java.util.Scanner;

public class Uzd02 {

	public static void main(String[] args) {
		Scanner rd = new Scanner(System.in);
		System.out.println("Įveskite pirmą skaičių: ");
		int m = rd.nextInt();
		System.out.println("Įveskite paskutinį skaičių: ");
		int n = rd.nextInt();
		int count = 0;
		while (m <= n) {

			count = count + getSum(m);
			m++;
			
//			arba
//			for (int i = m; i <= n; i++) {
//				count = count + getSum(i);
//			}
		}

		System.out.println(count);
		rd.close();
	}

	private static int getSum(int m) {
		int suma = 0;
		while (m > 0) {
			suma = suma + (m % 10);
			m = m / 10;
		}
		return suma;
	}
}
