import java.util.Scanner;

public class Uzd03 {

	public static void main(String[] args) {
		Scanner rd = new Scanner(System.in);
		System.out.println("Įveskite pirmą skaičių: ");
		int m = rd.nextInt();
		System.out.println("Įveskite paskutinį skaičių: ");
		int n = rd.nextInt();
		while (m <= n) {

			System.out.println(m + " - " + reverse(m));;
			m++;

		}

		rd.close();
	}

	private static int reverse(int m) {
		int reversed = 0;
		while(m != 0) {
            int digit = m % 10;
            reversed = reversed * 10 + digit;
            m /= 10;
		}
		return reversed;
	}
}
