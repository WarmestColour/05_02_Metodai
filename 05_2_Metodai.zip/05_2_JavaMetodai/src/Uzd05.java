import java.util.Scanner;

public class Uzd05 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);

		int m = 9;
		int counter = 0;
		int num;

		while (true) {
			System.out.print("Įveskite skaičių: ");
			num = reader.nextInt();
			if (num == 0) {
				break;
			}
			//System.out.println(kiek9(num,m));
			if (kiek9(num, m) == 2) {
				counter++;
			}
		}
		System.out.println(counter + " kartų");

		reader.close();
	}

	private static int kiek9(int a, int m) {
		int count = 0;
		while (a > 0) {

			if (a % 10 == 9) {
				count++;
			}
			a = a / 10;
		}
		return count;
	}
}