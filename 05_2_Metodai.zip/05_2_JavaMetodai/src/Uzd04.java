import java.util.Scanner;

public class Uzd04 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);

		int n = 6;
		int counter = 0;
		int num;

		while (true) {
			System.out.print("Įveskite skaičių: ");
			num = reader.nextInt();
			if (num == 0) {
				break;
			}

			if (n == getSum(num)) {
				counter++;
			}
		}
		System.out.println(counter + " kartų");

		reader.close();
	}

	private static int getSum(int a) {

		int sum = 0;
		while (a > 0) {
			sum = sum + (a % 10);
			a = a / 10;
		}
		return sum;
	}
}