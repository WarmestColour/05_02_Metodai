import java.util.Scanner;

public class Uzd01 {

	public static void main(String[] args) {
		Scanner rd = new Scanner(System.in);
		System.out.println("Įveskite pirmą skaičių: ");
		int m = rd.nextInt();
		System.out.println("Įveskite paskutinį skaičių: ");
		int n = rd.nextInt();
		int count = 0;
		while (m <= n) {

			if (m % getSum(m) == 0) {
				count++;
			}

			m++;
		}

		System.out.println(count);
		rd.close();
	}

	private static int getSum(int m) {
		int sum = 0;
		while (m != 0) {
			sum += m % 10;
			m /= 10;
		}
		return sum;
	}
}
